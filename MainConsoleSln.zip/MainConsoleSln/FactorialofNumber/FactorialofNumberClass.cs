﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactorialofNumber
{
    public class FactorialofNumberClass
    {
        public int FactorialMethod(int factorialNumber)
        {

            //for (int i = factorialNumber - 1; i >= 1; i--)
            //{
            //    factorialNumber = factorialNumber * i;
            //}
            int factorialResult = 1;
            if (factorialNumber > 1)
            {
                while (factorialNumber != 1)
                {
                    factorialResult = factorialResult * factorialNumber;
                    factorialNumber--;
                }
            }
            else
                return 1;
            return factorialResult;
        }
    }
}
