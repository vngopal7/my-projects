﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReverseLinkedList
{
    public class ReverseLinkedListClass
    {
        public LinkedList<string> ReverseLinkedListMethod(LinkedList<string> linkedList)
        {
            LinkedList<string> tempList = new LinkedList<string>();

            LinkedListNode<string> start = linkedList.Last;

            while (start != null)
            {
                tempList.AddLast(start.Value);
                start = start.Previous;
            }

            linkedList = tempList;
            return linkedList;
        }
    }
}
