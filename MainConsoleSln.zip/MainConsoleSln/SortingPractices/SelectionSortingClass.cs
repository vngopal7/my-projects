﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortingPractices
{
    public class SelectionSortingClass
    {
        public int[] SelectionSortingMethod(int[] arraylist)
        {
            int temp, minKey;
            for(int j = 0; j < arraylist.Length - 1; j++)
            {
                minKey = j;
                for(int k=j+1;k< arraylist.Length; k++)
                {
                    if(arraylist[k] < arraylist[minKey])
                    {
                        minKey = k;
                    }
                }
                temp = arraylist[minKey];
                arraylist[minKey] = arraylist[j];
                arraylist[j] = temp;
            }
            return arraylist;
        }
    }
}
