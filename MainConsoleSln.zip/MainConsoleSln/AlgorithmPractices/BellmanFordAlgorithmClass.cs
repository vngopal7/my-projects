﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgorithmPractices
{
    public class BellmanFordAlgorithmClass
    {
        public struct Edge
        {
            public int Source;
            public int Destination;
            public int Weight;
        }
        public struct Graph
        {
            public int VerticesCount;
            public int EdgesCount;
            public Edge[] Edges;
        }
        public static Graph CreateGraph(int vetricesCount, int edgesCount)
        {
            Graph graph = new Graph();
            graph.VerticesCount = vetricesCount;
            graph.EdgesCount = edgesCount;
            graph.Edges = new Edge[graph.EdgesCount];
            return graph;
        }

        private static void Send(int[] distance, int count)
        {
            Console.WriteLine("Vertex Distance from source");
            for (int i = 0; i < count; ++i)
            {
                Console.WriteLine("{0}\t {1}", i, distance[i]);
            }
        }
        public static void BellmanFordAlgorithmMethod(Graph graph, int source)
        {
            int verticesCount = graph.VerticesCount;
            int edgesCount = graph.EdgesCount;
            int[] distances = new int[verticesCount];
            for (int i = 0; i < verticesCount; i++)
            {
                distances[i] = int.MaxValue;
            }
            distances[source] = 0;
            for(int i = 1; i < verticesCount; ++i)
            {
                for(int j = 0; j < edgesCount - 1; ++j)
                {
                    int u = graph.Edges[j].Source;
                    int v = graph.Edges[j].Destination;
                    int weight = graph.Edges[j].Weight;
                    if(distances[u]!= int.MaxValue && distances[u] + weight < distances[v])
                    {
                        distances[v] = distances[u] + weight;
                    }
                }
            }
            for(int i = 0; i < edgesCount - 1; ++i)
            {
                int u = graph.Edges[i].Source;
                int v = graph.Edges[i].Destination;
                int weight = graph.Edges[i].Weight;
                if(distances[u]!=int.MaxValue && distances[u] + weight < distances[v])
                {
                    Console.WriteLine("Graph contains negative weight cycle.");
                }
            }
            Send(distances, verticesCount);

        }
    }
}
