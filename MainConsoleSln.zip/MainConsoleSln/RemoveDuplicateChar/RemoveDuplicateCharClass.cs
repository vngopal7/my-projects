﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RemoveDuplicateChar
{
    public class RemoveDuplicateCharClass
    {
        public string RemoveDuplicates(string key)
        {
            string temp = string.Empty;
            string result = string.Empty;
            foreach(char i in key)
            {
                if (temp.IndexOf(i) == -1)
                {
                    temp += i;
                    result += i;
                }
            }
            return result;
        }
    }
}
