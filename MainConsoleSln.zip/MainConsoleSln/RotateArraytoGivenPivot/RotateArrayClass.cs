﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RotateArraytoGivenPivot
{
    public class RotateArrayClass
    {
        public int[] RotateArray(int[] array, int pivot)
        {
            try
            {
                if (pivot <= 0 || array == null)

                    throw new Exception("invalid Argument Exception");
                pivot = pivot % array.Length;
                array = RotateSub(array, 0, pivot - 1);
                array = RotateSub(array, pivot, array.Length - 1);
                array = RotateSub(array, 0, array.Length - 1);
            }
            catch(Exception ex)
            {

            }
            return array;
        }
        public int[] RotateSub(int[] subarray,int begin, int end)
        {
            while (begin < end)
            {
                int temp = subarray[begin];
                subarray[begin] = subarray[end];
                subarray[end] = temp;
                begin++;
                end--;
            }
            return subarray;
        }
    }
}
