﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RotateArraytoGivenPivot;
using FactorialofNumber;
using ReverseLinkedList;
using SortingPractices;
using AlgorithmPractices;
using static AlgorithmPractices.BellmanFordAlgorithmClass;
using CodePracticeOnStrings;

namespace MainConsoletoCallQuestionCode
{
    class Program
    {
        public static void Main(string[] args)
        {

            CallRemoveDuplicateMethod();

            //CallRotateArray();

            //CallFactorial();

            //CallReverseLinkedList();

            //CallSelectionSort();
            //CallBellmanFordAlgorithm();

        }
        public static void CallRemoveDuplicateMethod()
        {
            try
            {
                string inputString = Console.ReadLine();
                RemoveDuplicateCharClass obj = new RemoveDuplicateCharClass();
                Console.WriteLine(obj.RemoveDuplicates(inputString));
            }
            catch (Exception e)
            {

            }
        }
        public static void CallRotateArray()
        {
            try
            {
                RotateArrayClass obj = new RotateArrayClass();
                Console.WriteLine("Enter Pivot:");
                int pivotnumber = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter total array count:");
                int count = int.Parse(Console.ReadLine());
                int[] array = new int[count];
                for (int i = 0; i < count; i++)
                {
                    string stringnumber = Console.ReadLine();
                    int number = Convert.ToInt32(stringnumber);
                    array[i] = number;
                }

                foreach (int i in obj.RotateArray(array, pivotnumber))
                {
                    Console.WriteLine(i);
                }
            }
            catch (Exception e)
            {

            }
        }
        public static void CallFactorial()
        {
            try
            {
                int number;
                Console.WriteLine("Enter the number: ");
                number = int.Parse(Console.ReadLine());
                FactorialofNumberClass factorialofNumberClassobj = new FactorialofNumberClass();
                Console.WriteLine(factorialofNumberClassobj.FactorialMethod(number));
            }
            catch (Exception E)
            {

            }
        }
        public static void CallReverseLinkedList()
        {
            string[] words = new string[] { "the", "fox", "jump", "over", "the", "dog" };
            LinkedList<string> sentence = new LinkedList<string>(words);
            ReverseLinkedListClass ReverseLinkedListClassObj = new ReverseLinkedListClass();
            foreach (string key in ReverseLinkedListClassObj.ReverseLinkedListMethod(sentence))
            {
                Console.WriteLine(key);
            }
        }
        public static void CallSelectionSort()
        {
            try
            {
                Console.WriteLine("Enter the Array Size:");
                int arraySize = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter array elements one by one: ");
                int[] arrayList = new int[arraySize];
                for (int i = 0; i < arraySize; i++)
                {
                    arrayList[i] = int.Parse(Console.ReadLine());
                }
                SelectionSortingClass selectionSortingClassObj = new SelectionSortingClass();
                Console.WriteLine("The order of elements are:");
                foreach(int element in selectionSortingClassObj.SelectionSortingMethod(arrayList))
                {
                    Console.WriteLine(element+"/");
                }
            }
            catch (Exception e)
            {

            }
        }

        public static void CallBellmanFordAlgorithm()
        {
            try
            {
                Console.WriteLine("Enter Vertices Count:");
                int verticesCount = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Edges Count");
                int edgesCount = int.Parse(Console.ReadLine());
                BellmanFordAlgorithmClass bellmanFordAlgorithmClassObj = new BellmanFordAlgorithmClass();
                Graph graph = CreateGraph(verticesCount, edgesCount);

                for(int i = 0; i < edgesCount; i++)
                {
                    Console.WriteLine("Enter Soruce for edge {0}",i);
                    graph.Edges[i].Source = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Destination for edge {0}", i);
                    graph.Edges[i].Destination = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Weight for edge {0}", i);
                    graph.Edges[i].Weight = int.Parse(Console.ReadLine());
                }
                Console.WriteLine("Enter Source Node");
                int initalSource = int.Parse(Console.ReadLine());
                BellmanFordAlgorithmMethod(graph, initalSource);
            }
            catch (Exception E)
            {
                
            }
        }

    }
}
